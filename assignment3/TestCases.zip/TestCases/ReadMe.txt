In folder "Queries", all queries are executed on the Edmonton RDF graph for Q9. 
In folder "RDF files", there are all test cases for Q8. 